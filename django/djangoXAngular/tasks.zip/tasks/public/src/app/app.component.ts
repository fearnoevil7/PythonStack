import { Component, OnInit } from '@angular/core';
import { HttpService } from './http.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'public';
  tasks: {};
  newTask: any;
  task: {};
  updatedTask: any;
  constructor(private _httpService: HttpService) {}

  ngOnInit(){
    this.newTask = { description: "", isCompleted: false };
    this.updatedTask = { description: "", isCompleted: false };
    this.getTasksFromService();
  }

  getTasksFromService(){
    let observable = this._httpService.getTasks();
    observable.subscribe(data => {
      console.log("Got our tasks!", data)
      this.tasks = data['tasks']
      console.log("**********tasks*******", this.tasks)
    })
  }
  addTask(){
    let observable = this._httpService.create(this.newTask);
    observable.subscribe(data => {
      console.log("Got our data back from the post", data);
      this.newTask = { description: "", isCompleted: false }
    })
  }

  sendToDestroy(id){
    console.log(id);
    let observable = this._httpService.destroy(id)
    observable.subscribe(data => {
      this.getTasksFromService;
    })
  }

  showTask(id){
    let observable = this._httpService.getTask(id);
    observable.subscribe(data => {
      this.task = data;
      console.log("Got our task!!!!!!!!", this.task);
    })
  }

  complete(id){
    console.log("success")
    this.showTask((id));
    console.log(this.updatedTask);
    console.log("Task selected to edit       !!!!!!!!", this.updatedTask)
    let observable = this._httpService.completeTask(id, this.updatedTask);
    observable.subscribe(data => {
      this.getTasksFromService;
    })
  }

}
