import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  constructor(private _http: HttpClient) { }

  getTasks(){
    return this._http.get("/task")
  }
  create(task){
    return this._http.post("/task", task)
  }
  destroy(id){
    console.log("Http")
    console.log(typeof(id))
    return this._http.delete('/task/' + id);
  }
  completeTask(id, task){
    console.log(id)
    console.log("http", task)
    return this._http.put('/task/' + id, task)
  }

  getTask(id){
    return this._http.get("/task/" + id)
  }
}
