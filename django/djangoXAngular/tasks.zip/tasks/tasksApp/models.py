from django.db import models


class Task(models.Model):
    description = models.TextField()
    isCompleted = models.BooleanField()
# Create your models here.
