from django.apps import AppConfig


class TasksappConfig(AppConfig):
    name = 'tasksApp'
