from django.shortcuts import render
from django.views import View
from django.http import JsonResponse
from .models import Task
import json

class task(View):
    def get(self, request):
        return JsonResponse({'status': 'ok', 'tasks': list(Task.objects.values().all())})
    def post(self, request):
        body = json.loads(request.body.decode())
        print(body, type(body))
        new_task = Task.objects.create(description = body['description'], isCompleted = body['isCompleted'])
        print(new_task)
        return JsonResponse({'status': 'ok'})
    def delete(self, request, task_id):
        print("Hoooraaaayyyyy")
        print(task_id)
        task1 = Task.objects.get(id=task_id)
        task1.delete()
        return JsonResponse({'status': 'ok'})
    
class show(View):
    def delete(self, request, task_id):
        print("Hoooraaaayyyyy")
        print(task_id)
        task1 = Task.objects.get(id=task_id)
        task1.delete()
        return JsonResponse({'status': 'ok'})

    def get(self, request, task_id):
        print("Testing123")
        task2 = Task.objects.values().get(id=task_id)
        # task2.isCompleted = True
        # print(task2.isCompleted)
        return JsonResponse({'status': 'ok', 'task': task2})

    def put(self, request, task_id):
        task3 = Task.objects.get(id=task_id)
        
        print(task3)
        if task3.isCompleted == True:
            task3.isCompleted = False
        
        if task3.isCompleted == False:
            task3.isCompleted = True
        task3.save()
        print("*******task!!!!!!!", task3.isCompleted)
        return JsonResponse({'status': 'ok'})
# Create your views here.
